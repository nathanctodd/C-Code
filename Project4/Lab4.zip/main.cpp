#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "DatalogProgram.h"
#include "Database.h"
#include "Scanner.h"
#include "Relation.h"
#include "Parser.h"

using namespace std;

int main(int argc, char *argv[]) {

    // string fileName = argv[1];
    // //string fileName = "test.txt";
    // ifstream input(fileName);
    // stringstream inputStream;
    // while (!input.eof()) {
    //     string next;
    //     getline(input, next);
    //     inputStream << next << endl;
    // }

    // Scanner scanner = Scanner(inputStream.str());
    // scanner.scanTokens(inputStream.str());
    // vector<Token> tokenInput = scanner.getTokenVector();
    // Parser p = Parser(tokenInput);
    // p.parseDatalogProgram();
    // DatalogProgram data = p.getDatalog();
    // vector<Relation> relationVector;
    // Database database(data, relationVector);
    // database.evaluateSchemes();
    // database.evaluateFacts();
    // database.evaluateQueries();
    // //cout << data.toString();

    // vector<string> first;
    // first.push_back("A");
    // first.push_back("B");
    // vector<string> second;
    // second.push_back("B");
    // second.push_back("C");    
    // vector<string> third;
    // third.push_back("'1'");
    // third.push_back("'2'");  
    // vector<string> fourth;
    // fourth.push_back("'3'");
    // fourth.push_back("'4'");    
    // vector<string> first2;
    // first2.push_back("X");
    // first2.push_back("Y"); 
    // vector<string> first3;
    // first3.push_back("X");
    // first3.push_back("Y"); 
    // first3.push_back("Z"); 

    // vector<string> first4;
    // first4.push_back("'1'");
    // first4.push_back("'4'"); 
    // vector<string> first5;
    // first5.push_back("'1'");
    // first5.push_back("'2'"); 
    // first5.push_back("'4'"); 


    // Scheme scheme1(first);
    // Scheme scheme2(second);
    // Scheme scheme3(first2);
    // Scheme scheme4(first3);

    // Tuple tuple1(third);
    // Tuple tuple2(fourth);
    // Tuple tuple3(first4);
    // Tuple tuple4(first5);

    //Partial, undefined, function, undefined

    // cout << Relation::joinable(scheme1, scheme2, tuple1, tuple2) << endl;
    // cout << Relation::joinable(scheme2, scheme3, tuple1, tuple2) << endl;
    // cout << Relation::joinable(scheme3, scheme4, tuple1, tuple4) << endl;
    // cout << Relation::joinable(scheme3, scheme4, tuple3, tuple4) << endl;

    vector<string> bruh;
    bruh.push_back("ID");
    bruh.push_back("Name");
    bruh.push_back("Major");

    Relation studentRelation("students", Scheme(bruh));

    vector<string> bruh2;
        bruh2.push_back("'42'");
        bruh2.push_back("'Ann'");
        bruh2.push_back("'CS'");
    vector<string> bruh3;
        bruh3.push_back("'64'");
        bruh3.push_back("'Ned'");
        bruh3.push_back("'EE'");

    vector< vector<string> > studentValues;
    studentValues.push_back(bruh2);
    studentValues.push_back(bruh3);

    for (unsigned i = 0; i < studentValues.size(); i++) {
        studentRelation.addTuple(studentValues[i]);
    }

    vector<string> newest;
    newest.push_back("ID");
    newest.push_back("Course");

    Relation courseRelation("courses", Scheme(newest));

    vector<string> bro;
        bro.push_back("'42'");
        bro.push_back("'CS 100'");
    vector<string> bro2;
        bro2.push_back("'32'");
        bro2.push_back("'CS 232'");

    vector< vector<string> > nextValues;
    nextValues.push_back(bro);
    nextValues.push_back(bro2);

    for (unsigned i = 0; i < nextValues.size(); i++) {
        courseRelation.addTuple(nextValues[i]);
    }

    studentRelation.join(courseRelation);

    //Not injective or surjective
    //Bijection
    //Surjective but not injective
    //Injective, not surjective

}
