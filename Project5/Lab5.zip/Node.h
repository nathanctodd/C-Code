#pragma once
#include <iostream>
#include <string>
#include <set>
#include <map>
#include <sstream>

using namespace std;

class Node {

    private:
        set<int> adjacentNodeIDs;
        bool beenVisited;
        int postOrderNumber;

    public:

    void addEdge(int adjacentNodeID) {
        adjacentNodeIDs.insert(adjacentNodeID); 
    }

    bool hasBeenVisited() {
        return beenVisited;
    }

    void setVisited(bool visited) {
        beenVisited = visited;
    }

    void setPostOrderNumber(int num) {
        postOrderNumber = num;
    }

    int getPostOrderNumber() {
        return postOrderNumber;
    }

    string toString() {
        stringstream out;
        set<int>::iterator itr;
        for (itr = adjacentNodeIDs.begin(); itr != adjacentNodeIDs.end(); itr++) {
            if (itr == adjacentNodeIDs.begin()) {
                out << "R" << (*itr);
            } else {
                out << ",R" << (*itr);
            }
        }   
        return out.str();
    }

};