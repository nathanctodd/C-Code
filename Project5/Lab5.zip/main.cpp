#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include "DatalogProgram.h"
#include "Database.h"
#include "Scanner.h"
#include "Relation.h"
#include "Parser.h"
#include "Rule.h"


using namespace std;


int main(int argc, char *argv[]) {

    // Node node;
    // node.addEdge(8);
    // node.addEdge(4);
    // node.addEdge(2);
    // cout << node.toString() << endl;

    // Graph graph(3);
    // graph.addEdge(1,2);
    // graph.addEdge(1,0);
    // graph.addEdge(0,1);
    // graph.addEdge(1,1);
    // cout << graph.toString() << endl;


  // predicate names for fake rules
  // first is name for head predicate
  // second is names for body predicates
  vector< pair<string,vector<string> > >ruleNames;
  vector<string> first;
  first.push_back("Sibling");
  pair<string, vector<string> > firstPair;
  firstPair.first = "Sibling";
  firstPair.second = first;
  ruleNames.push_back(firstPair);

  vector<string> second;
  second.push_back("Parent");
  second.push_back("Ancestor");
  pair<string, vector<string> > secondPair;
  secondPair.first = "Ancestor";
  secondPair.second = second;
  ruleNames.push_back(secondPair);

  vector<string> third;
  third.push_back("Parent");
  pair<string, vector<string> > thirdPair;
  thirdPair.first = "Ancestor";
  thirdPair.second = third;
  ruleNames.push_back(thirdPair);


  vector<Rule> rules;

  
  for (int i = 0; i < ruleNames.size(); i++) {
    pair<string, vector<string> > rulePair = ruleNames[i];
    string headName = rulePair.first;
    Rule rule = Rule(Predicate(headName));
    vector<string> bodyNames = rulePair.second;
    for (int k = 0; k < bodyNames.size(); k++) {
        string bodyName = bodyNames[i];
        rule.addToRules(Predicate(bodyName));
    }
    rules.push_back(rule);
  }
  Graph graph = Database::makeGraph(rules);
  cout << graph.toString();





}